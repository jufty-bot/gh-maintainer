import json,concurrent.futures
from run import ROOT
from gather import run_silent,budgets

def state(case):
 res={}
 for kind in ['issues','prs']:
  p=run_silent(['--db',ROOT/f'{case}.sqlite',kind,'--repo','owner/project','--state','all','--unprocessed','--limit','100','--format','json']);res[kind]=json.loads(p.stdout)
 for item in ['I_1','I_2','I_3','I_4']+(['I_5','I_6'] if case=='pagination' else []):
  p=run_silent(['--db',ROOT/f'{case}.sqlite','show',item,'--format','json']);res[item]=json.loads(p.stdout)
 (ROOT/f'{case}-final.json').write_text(json.dumps(res,indent=2))
 print(case,'PENDING',[(kind,res[kind]['total']) for kind in ['issues','prs']], 'ITEMS',[(k,v['item']['revision'],v['item']['processing_state']) for k,v in res.items() if k.startswith('I_')])
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as p:list(p.map(state,['pagination','prior','hostile','missing','read-limit','ordinary','rerun']))
