import json, subprocess, sqlite3, pathlib, sys
ROOT=pathlib.Path('<EVAL>')
CLI=str(ROOT/'venv/bin/gh-maintainer')
def run(args):
    argv=[CLI,*map(str,args)]
    p=subprocess.run(argv,cwd=ROOT,text=True,capture_output=True)
    with (ROOT/'commands.jsonl').open('a') as f:f.write(json.dumps({'argv':argv,'cwd':str(ROOT),'stdout':p.stdout,'stderr':p.stderr,'exit':p.returncode})+'\n')
    print(json.dumps({'argv':argv,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}))
    return p
if __name__=='__main__':run(sys.argv[1:])
