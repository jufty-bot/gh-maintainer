import json,sys
from run import ROOT
for c in sys.argv[1:]:
 e=json.loads((ROOT/f'{c}-inspection.json').read_text());print('\nCASE',c,e['queue_totals'],e['selected'],e.get('blocked'))
 print('COVERAGE',[(r['synced_at'],r['comments_synced_at'],r['error']) for r in e['repo']['repos']])
 for x in e.get('items',[]):
  a=x['before']['item'];b=x['after']['item'];print('ITEM',json.dumps(a));print('RECHECK',b['revision'],b['available'],b['present'],b['repo_error'])
  for cmd in ['comments','changes']:
   for p in x[cmd]:
    print(cmd,'TOTAL',p['total'],'COVERAGE',{k:v for k,v in p.items() if k not in [cmd,'total']})
    for y in p[cmd]:
     if cmd=='comments':print(y['id'],y['url'],y['body'])
     else: print('change',json.dumps(y))
