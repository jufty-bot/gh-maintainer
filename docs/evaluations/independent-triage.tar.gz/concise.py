from run import ROOT
import json,sys
for c in sys.argv[1:]:
 e=json.loads((ROOT/f'{c}-inspection.json').read_text());print('CASE',c,'QUEUES',e['queue_totals'],'SELECTED',e['selected'])
 for o in e.get('items',[]):
  print('ITEM',json.dumps(o['before']['item']));print('RECHECK',json.dumps({k:o['after']['item'][k] for k in ['revision','available','present','repo_error','comments_synced_at']}))
  for p in o['comments']:
   print('COMMENTS',p['total'],p['comments_synced_at'],p['coverage_error'])
   for x in p['comments']:print(x['id'],x['body'])
  for p in o['changes']:
   print('CHANGES',p['total'])
   for x in p['changes']:
    a=x['after_json'];b=x['before_json'];print(x['id'],x['kind'],x['revision'],'BEFORE',b,'AFTER',a.get('id'),a.get('body',a.get('raw',{}).get('body')),a.get('state'))
