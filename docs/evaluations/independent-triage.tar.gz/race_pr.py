import json,sys,sqlite3,subprocess
from run import ROOT
from gather import run_silent
REPO='<REPO>'
def log_external(argv):
 p=subprocess.run(argv,cwd=REPO,text=True,capture_output=True)
 with (ROOT/'fixture-commands.jsonl').open('a') as f:f.write(json.dumps({'argv':argv,'cwd':REPO,'stdout':p.stdout,'stderr':p.stderr,'exit':p.returncode})+'\n')
 print('FIXTURE',p.returncode);return p
case=sys.argv[1];action=sys.argv[2]
def call(*a):
 p=run_silent(['--db',ROOT/f'{case}.sqlite',*a]);return (json.loads(p.stdout) if p.stdout.startswith('{') else p.stdout) if p.returncode==0 else {'exit':p.returncode,'stderr':p.stderr}
if action=='copy':
 s=sqlite3.connect('file:<FIXTURES>/eval-race.sqlite?mode=ro',uri=True);d=sqlite3.connect(ROOT/f'{case}.sqlite');s.backup(d);s.close();d.close()
elif action=='inspect':
 e={'db':call('db','path'),'repos':call('repos','--format','json'),'issues':call('issues','--repo','owner/project','--state','all','--unprocessed','--limit','2','--format','json'),'prs':call('prs','--repo','owner/project','--state','all','--unprocessed','--limit','2','--format','json'),'before':call('show','I_2','--format','json'),'comments':call('comments','I_2','--limit','100','--format','json'),'changes':call('changes','I_2','--limit','100','--format','json'),'after':call('show','I_2','--format','json')}
 (ROOT/f'{case}-{sys.argv[3]}-inspection.json').write_text(json.dumps(e,indent=2));print(json.dumps(e))
elif action=='advance':log_external(['uv','run','--locked','python','-m','tests.triage_fixtures','advance',str(ROOT/f'{case}.sqlite'),'--scenario','race'])
elif action=='stale':print(json.dumps(call('summarize','I_2','PR draft after inspection; revision guard should reject stale source.','--revision',sys.argv[3],'--producer','gh-maintainer-triage/v2','--reason','Race evaluation','--format','json')))
