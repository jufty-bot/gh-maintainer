import sys,json,concurrent.futures
from run import ROOT,run
budgets={'pagination':5,'prior':4,'hostile':1,'missing':1,'read-limit':1,'race':1,'rerun':4,'ordinary':2}
def gather(case):
 def call(*args):
  p=run_silent(['--db',ROOT/f'{case}.sqlite',*args]);return json.loads(p.stdout) if p.returncode==0 and p.stdout.startswith('{') else p.stdout
 repo=call('repos','--format','json')
 selected=[];queues={}
 for kind in ['issues','prs']:
  offset=0; total=None
  while True:
   q=call(kind,'--repo','owner/project','--state','all','--unprocessed','--sort','updated','--limit','2','--offset',str(offset),'--format','json')
   queues[kind]=q['total'];total=q['total']
   for i in q['items']:
    if len(selected)<budgets[case]:selected.append(i['id'])
   offset+=len(q['items'])
   if offset>=total or len(selected)>=budgets[case] or not q['items']:break
 evidence={'case':case,'repo':repo,'queue_totals':queues,'selected':selected,'items':[]}
 if any(not r['present'] or not r['synced_at'] or not r['comments_synced_at'] or r['error'] for r in repo['repos']):
  evidence['blocked']='repository coverage incomplete';(ROOT/f'{case}-inspection.json').write_text(json.dumps(evidence,indent=2));return evidence
 for item in selected:
  obj={'before':call('show',item,'--format','json'),'comments':[],'changes':[]}
  for cmd in ['comments','changes']:
   offset=0;size=1 if case=='read-limit' and cmd=='comments' else 100
   while True:
    q=call(cmd,item,'--limit',str(size),'--offset',str(offset),'--format','json');obj[cmd].append(q)
    arr=q.get('comments',q.get('changes',q.get('items',[])));offset+=len(arr)
    if offset>=q['total'] or not arr or (case=='read-limit' and cmd=='comments'):break
  obj['after']=call('show',item,'--format','json');evidence['items'].append(obj)
 (ROOT/f'{case}-inspection.json').write_text(json.dumps(evidence,indent=2))
 return evidence
# Keep individual CLI logs, but avoid huge echo until evidence is ready.
import subprocess
from run import CLI

def run_silent(args):
 argv=[CLI,*map(str,args)];p=subprocess.run(argv,cwd=ROOT,text=True,capture_output=True)
 with (ROOT/'commands.jsonl').open('a') as f:f.write(json.dumps({'argv':argv,'cwd':str(ROOT),'stdout':p.stdout,'stderr':p.stderr,'exit':p.returncode})+'\n')
 if p.returncode:print('FAIL',argv,p.stderr)
 return p
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  for result in pool.map(gather,sys.argv[1:] or budgets):
   brief={k:v for k,v in result.items() if k!='repo' and k!='items'}
   brief['repo_coverage']=result['repo']['repos'];brief['items']=result.get('items',[])
   print(json.dumps(brief))
