import json
from run import ROOT
from gather import run_silent
h='7b74f48ac0546c05cdda007f33d74dc4c2705fec09208396d4754ac63907a779'
reason='Policy '+h+'; https://github.com/owner/project/issues/1 states expected defaults versus startup exit; C_1_1 https://github.com/owner/project/issues/1#issuecomment-1 reports reproduction with empty config. This meets reported-malfunction and band 2 (blocked startup, specific reproduction claim); broad impact is unverified, so band 3 is unsupported.'
def call(*a):
 p=run_silent(['--db',ROOT/'policy.sqlite',*a]);print(p.stdout,p.stderr);return p
call('show','I_1','--format','json')
for cmd,args in [('classify',['reported-malfunction']),('rank',['2'])]:
 p=call(cmd,'I_1',*args,'--revision','1','--policy',ROOT/'policy.json','--producer','gh-maintainer-prioritize/v1','--reason',reason,'--format','json');assert p.returncode==0
p=call('mark-processed','I_1','--revision','1','--policy',ROOT/'policy.json','--actor','gh-maintainer-prioritize/v1','--format','json');assert p.returncode==0
p=call('show','I_1','--format','json');(ROOT/'policy-final.json').write_text(p.stdout)
for cmd in ['issues','prs']:call(cmd,'--repo','owner/project','--state','all','--unprocessed','--limit','2','--format','json')
