import json,subprocess
from run import ROOT
from gather import run_silent
x=json.loads((ROOT/'race-exhaust-retry-inspection.json').read_text());a=x['after']['item']
assert a['revision']==2 and x['before']['item']['revision']==2 and x['comments']['total']==1 and x['changes']['total']==5
print('FULL RETRY',a['revision'],a['pr']['head'],[(c['id'],c['body']) for c in x['comments']['comments']],[(c['kind'],c['revision']) for c in x['changes']['changes']])
summary='https://github.com/owner/project/issues/2: PR asks maintainer to decide empty-config validation behavior. Revision 2 inspected after one retry: pushed head abc -> updated-head; edited C_2_1 https://github.com/owner/project/issues/2#issuecomment-1 now claims default behavior changed. All five observations and one covered comment inspected. Indexed successful checks do not prove correctness. Next: agree behavior, then technically inspect updated-head; no code review performed.'
def call(*a):return run_silent(['--db',ROOT/'race-exhaust.sqlite',*a])
p=call('summarize','I_2',summary,'--revision','2','--producer','gh-maintainer-triage/v2','--reason','Full retry reread completed; source URLs in summary','--format','json');assert p.returncode==0
argv=['uv','run','--locked','python','-m','tests.triage_fixtures','advance',str(ROOT/'race-exhaust.sqlite'),'--scenario','race','--generation','2'];cwd='<REPO>'
p=subprocess.run(argv,cwd=cwd,text=True,capture_output=True)
with (ROOT/'fixture-commands.jsonl').open('a') as f:f.write(json.dumps({'argv':argv,'cwd':cwd,'stdout':p.stdout,'stderr':p.stderr,'exit':p.returncode})+'\n')
assert p.returncode==0
p=call('mark-processed','I_2','--revision','2','--actor','gh-maintainer-triage/v2','--format','json');print('ACKNOWLEDGEMENT',p.returncode,p.stderr);assert p.returncode==1
p=call('show','I_2','--format','json');(ROOT/'race-exhaust-final.json').write_text(p.stdout);a=json.loads(p.stdout)['item'];print('FINAL',a['revision'],a['processing_state'],a['summary']);assert a['revision']==3 and a['processing_state']=='unprocessed' and a['summary']['source_revision']==2 and a['summary']['stale']
for kind in ['issues','prs']:
 p=call(kind,'--repo','owner/project','--state','all','--unprocessed','--limit','2','--format','json');print(kind,json.loads(p.stdout)['total'])
