import pathlib, sqlite3, json
r=pathlib.Path('<EVAL>')
for case in ['pagination','prior','hostile','missing','read-limit','race','rerun','ordinary']:
 s=sqlite3.connect(f'file:<FIXTURES>/eval-{case}.sqlite?mode=ro',uri=True)
 d=sqlite3.connect(r/f'{case}.sqlite');s.backup(d);d.close();s.close()
(r/'identity.json').write_text(json.dumps({'agent':'Codex independent subagent /root/independent_triage','model':'not explicitly exposed to this agent; inherited parent model per orchestrator','cli':'0.2.0','triage':'gh-maintainer-triage/v2','prioritization':'gh-maintainer-prioritize/v1','constraints':'No credentials, no GitHub, no implementation or evaluation reports; only allowed docs, installed skills, public CLI and fixture source advancement.'},indent=2))
