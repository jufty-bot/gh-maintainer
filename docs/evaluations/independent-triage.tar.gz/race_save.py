import json
from run import ROOT
from gather import run_silent
s='https://github.com/owner/project/issues/2: PR proposes empty-config errors and asks for maintainer policy. Inspected revision 2 after one source-race retry: head changed abc -> updated-head; C_2_1 https://github.com/owner/project/issues/2#issuecomment-1 was edited from a validation-review request to a claim that the new head changes default behavior. Inspected all five pending observations and the covered comment. Indexed checks are successful and review remains required; code correctness/default behavior have not been verified. Next: maintainer decides intended empty-config behavior, then request technical review of updated-head.'
def call(*a):
 p=run_silent(['--db',ROOT/'race-pr.sqlite',*a]);assert p.returncode==0;return p
p=call('show','I_2','--format','json');assert json.loads(p.stdout)['item']['revision']==2
call('summarize','I_2',s,'--revision','2','--producer','gh-maintainer-triage/v2','--reason','Full reread after revision conflict; edited C_2_1 and pushed observation cited in summary','--format','json')
call('mark-processed','I_2','--revision','2','--actor','gh-maintainer-triage/v2','--format','json')
p=call('show','I_2','--format','json');(ROOT/'race-pr-final.json').write_text(p.stdout)
for kind in ['issues','prs']:call(kind,'--repo','owner/project','--state','all','--unprocessed','--limit','2','--format','json')
