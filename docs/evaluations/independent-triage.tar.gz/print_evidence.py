import sys,json
from run import ROOT
for case in sys.argv[1:]:
 e=json.loads((ROOT/f'{case}-inspection.json').read_text());print('CASE',case,'QUEUES',e['queue_totals'],'SELECTED',e['selected'],'BLOCKED',e.get('blocked'))
 for i in e.get('items',[]):
  print('SHOW',json.dumps(i['before']))
  for cmd in ['comments','changes']:
   for p in i[cmd]:print(cmd,json.dumps(p))
  print('RECHECK',i['after'].get('revision'),i['after'].get('processing_state'))
