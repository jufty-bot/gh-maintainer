from run import ROOT
import json
results=[]
for case in ['pagination','prior','hostile']:
 b=json.loads((ROOT/f'{case}-inspection.json').read_text());a=json.loads((ROOT/f'{case}-final.json').read_text())
 for x in b['items']:
  before=x['before']['item'];after=a[before['id']]['item']
  preserved=all(before[k]==after[k] for k in ['disposition','note','snoozed_until','classification','ranking'])
  results.append({'case':case,'id':before['id'],'prior_fields_preserved':preserved,'processing_state':after['processing_state'],'processed_revision':after['processed_revision'],'summary':after['summary']})
  assert preserved
for case in ['ordinary','read-limit']:
 b=json.loads((ROOT/f'{case}-inspection.json').read_text());a=json.loads((ROOT/f'{case}-final.json').read_text())
 for x in b['items']:
  before=x['before']['item'];after=a[before['id']]['item'];assert before==after
  results.append({'case':case,'id':before['id'],'public_item_state_unchanged':True})
policy=json.loads((ROOT/'policy-final.json').read_text())['item']
assert policy['classification']['labels']==['reported-malfunction'] and policy['ranking']['score']==2 and policy['processed_by']=='gh-maintainer-prioritize/v1'
race=json.loads((ROOT/'race-pr-final.json').read_text())['item']
assert race['revision']==2 and race['processed_revision']==2 and 'updated-head' in race['summary']['text'] and 'C_2_1' in race['summary']['text']
results.extend([{'case':'policy','verified':True},{'case':'race-pr','verified':True}])
(ROOT/'verification.json').write_text(json.dumps(results,indent=2));print('Post-decision assertions passed.')
