import json, pathlib, subprocess, sys, time
root=pathlib.Path('<EVAL>')
label=sys.argv[1]; argv=sys.argv[2:]
p=subprocess.run(argv,capture_output=True,text=True)
(root/(label+'.stdout')).write_text(p.stdout)
(root/(label+'.stderr')).write_text(p.stderr)
with (root/'commands.jsonl').open('a') as f: f.write(json.dumps({'label':label,'argv':argv,'cwd':str(pathlib.Path.cwd()),'exit':p.returncode,'stdout':label+'.stdout','stderr':label+'.stderr'})+'\n')
print(json.dumps({'label':label,'exit':p.returncode,'stdout_chars':len(p.stdout),'stderr_chars':len(p.stderr)}))
