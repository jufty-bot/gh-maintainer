"""Isolated reproduction against the exact inspected 0001 migration blob."""
import importlib.util
from pathlib import Path
import sqlalchemy as sa
from alembic.migration import MigrationContext
from alembic.operations import Operations

path = Path('<EVAL>/review-checkout/src/gh_maintainer/migrations/versions/0001_initial.py')
spec = importlib.util.spec_from_file_location('inspected_initial', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
engine = sa.create_engine('sqlite:///:memory:')
with engine.begin() as conn:
    for table, columns in module.EXPECTED.items():
        declarations = ', '.join('"'+column+'" TEXT' for column in sorted(columns))
        conn.exec_driver_sql('CREATE TABLE "'+table+'" ('+declarations+')')
    print('Before: items PK =', sa.inspect(conn).get_pk_constraint('items'))
    print('Before: items unique =', sa.inspect(conn).get_unique_constraints('items'))
    with Operations.context(MigrationContext.configure(conn)):
        module.upgrade()
    print('Unexpected: upgrade accepted tables with matching names but no PK/FK/unique constraints')
    conn.exec_driver_sql("INSERT INTO items (id, repo_id, number) VALUES ('same', 'repo', '1'), ('same', 'repo', '1')")
    count = conn.exec_driver_sql("SELECT COUNT(*) FROM items WHERE id='same'").scalar_one()
    print('Duplicate identities accepted:', count)
    assert count == 2
